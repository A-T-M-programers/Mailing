package xyz.luan.audioplayers

enum class ReleaseMode {
    RELEASE, LOOP, STOP
}